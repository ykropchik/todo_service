<?php

namespace Doctrine\DBAL\Driver\PDO\PgSQL;

use Doctrine\DBAL\Driver\PDOPgSql;

final class Driver extends PDOPgSql\Driver
{
}
