<?php

declare (strict_types=1);
namespace Symplify\EasyCodingStandard\Exception;

use Exception;
final class VersionException extends \Exception
{
}
