<?php

declare (strict_types=1);
namespace Symplify\EasyCodingStandard\Parallel\Exception;

use Exception;
final class ParallelShouldNotHappenException extends \Exception
{
}
