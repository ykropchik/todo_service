<?php

declare (strict_types=1);
namespace Symplify\EasyCodingStandard\Testing\Exception;

use Exception;
final class ShouldNotHappenException extends \Exception
{
}
