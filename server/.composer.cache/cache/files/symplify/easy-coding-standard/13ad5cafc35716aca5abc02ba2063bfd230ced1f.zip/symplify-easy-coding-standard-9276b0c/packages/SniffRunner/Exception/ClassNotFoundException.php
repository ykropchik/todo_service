<?php

declare (strict_types=1);
namespace Symplify\EasyCodingStandard\SniffRunner\Exception;

use Exception;
final class ClassNotFoundException extends \Exception
{
}
