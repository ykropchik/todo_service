<?php

declare (strict_types=1);
namespace Symplify\EasyCodingStandard\Caching\Exception;

use Exception;
final class CachingException extends \Exception
{
}
