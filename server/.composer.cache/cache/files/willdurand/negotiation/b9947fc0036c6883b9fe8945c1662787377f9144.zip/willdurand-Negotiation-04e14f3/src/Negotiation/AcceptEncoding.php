<?php

namespace Negotiation;

final class AcceptEncoding extends BaseAccept implements AcceptHeader
{
}
